# TCP

![](./~img/TCP状态转换图.png)