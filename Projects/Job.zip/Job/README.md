# Intro

* [牛客网](http://newcoder.com)
* [剑指Offer]()
* [笔试面试知识整理](https://hit-alibaba.github.io/interview/)

# 行为面试

![](./~img/行为面试题准备.png)

![](./~img/技术面试基础知识.png)

![](./~img/2的幂表.png)
# 知识点

## 字符串 

## 数组

## 链表

## 二叉树

## 归纳递推

## 递归