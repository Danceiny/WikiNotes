# 运算性质

- O(f) + O(g) = O(max(f,g))

- O(f) + O(g) = O(f+g)

- O(f)O(g) = O(fg)

- 如果g(N)=O(f(N)), 则O(f)+O(g)=O(f)

- O(Cf(N)) = O(f(N))，C为正的常数

- f = O(f)

