http://blog.csdn.net/ithomer/article/details/6252552

http://wiki.jikexueyuan.com/project/java-interview-bible/platorm-memory.html