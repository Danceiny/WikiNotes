# coding=utf-8

from shortuuid import uuid


def generate_uuid():
    """
    Generate uuid that is used for experiments and modules
    """
    return uuid()
