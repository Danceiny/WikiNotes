# coding=utf-8

from russell.cli.utils import py2code

py2code()